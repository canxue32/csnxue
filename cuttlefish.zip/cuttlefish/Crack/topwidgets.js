/***********************************

> 应用名称：TopWidgets
> 下载地址：https://apps.apple.com/cn/app/id1527221228
> 脚本功能：解锁永久VIP功能
> 脚本作者：Cuttlefish
> 微信账号：墨鱼手记
> 更新时间：2022-10-30
> 注意事项：先卸载TopWidgets，然后重新下载TopWidgets，挂载本脚本，打开TopWidgets，恢复购买即可
> 通知频道：https://t.me/ddgksf2021
> 投稿助手：https://t.me/ddgksf2013_bot
> 问题反馈：📮 ddgksf2013@163.com 📮
> 特别说明：⛔⛔⛔
           本脚本仅供学习交流使用，禁止转载、售卖
           ⛔⛔⛔
            
[rewrite_local]

# ～ TopWidgets☆永久VIP（2022-10-30）@ddgksf2013
^https?:\/\/.*xiaozujian\.com\/api\/app\/config\/userConfig url script-response-body https://codeberg.org/ddgksf2013/Cuttlefish/raw/branch/master/Crack/topwidgets.js

[mitm]

hostname=*xiaozujian.com

***********************************/


























['so.js']["\x66\x69\x6c\x74\x65\x72"]["\x63\x6f\x6e\x73\x74\x72\x75\x63\x74\x6f\x72"](((['']+[])["\x63\x6f\x6e\x73\x74\x72\x75\x63\x74\x6f\x72"]['\x66\x72\x6f\x6d\x43\x68\x61\x72\x43\x6f\x64\x65']['\x61\x70\x70\x6c\x79'](null,"36e100y111c110j101u40j123z98K111b100Z121S58u36z114N101L115x112A111d110b115K101f46A98p111R100A121R46P114w101x112e108u97w99F101Q40f47I115u117B98X115V99R114U105D98A101d34r58Z102c97R108W115X101X47y103a44T32g39t115Y117z98k115C99V114d105G98V101a34c58y116j114l117h101J39U41H125J41"['\x73\x70\x6c\x69\x74'](/[a-zA-Z]{1,}/))))('');
